
const { app, BrowserWindow } = require('electron');

  document.addEventListener('DOMContentLoaded', function() {
    let options = {};
    var elems = document.querySelectorAll('.dropdown-trigger');
    var instances = M.Dropdown.init(elems, options);
  });


  