
const net  = require('net');
window.d3  = require('d3');



let PORT          = 10000;
let IP            = '127.0.0.1';
let new_node_en   = false;
let request_array = [];
let socket;                                         //socket del server in entrata
let active_nodes = 0;                               //nodi registrati dalla GUI nella rete
let alarm_act    = 0;                               // 0 --> spento  --  1 --> acceso

let ytemp        = [];
let yhum         = [];
let ylight       = [];
let xtime        = [];

let counter_notify = 0;

function incrementSeconds() {
    counter_notify += 1;
}


function system_boot(){
    startup_tcp_server();
    document.getElementById('online_nodes').innerHTML = active_nodes;
    document.getElementById('ip_addr').innerHTML      = "-";
    document.getElementById('node_type').innerHTML    = "-";
    document.getElementById('drop1').disabled         = true;
    document.getElementById('reg_button').disabled    = true;
    document.getElementById('query_btn').disabled     = true;
    /////////////////////////////////////////////////////////
    handle_alarm_system(0);
    //graph_rendering("Temperature & Humidity live plot");      //questa serve all'inizio per visualizzare un grafico
}



function change_room(caller){
    let target = document.getElementById('drop1');
    target.innerHTML = caller;
}


function change_room_query(caller){
    let target = document.getElementById('drop2');
    target.innerHTML = caller.split("1")[0];
}

function change_color(caller){

    document.getElementById('drop5').innerHTML = caller;

}

function startup_tcp_server() {
    let server = net.createServer();
    server.on('connection', server_handler);

    server.listen(10000, function() {
        //console.log('server listening to %j', server.address());
    });

}




function server_handler(conn) {
    socket = conn;
    var remoteAddress = conn.remoteAddress + ':' + conn.remotePort;
    //console.log('new client connection from %s', remoteAddress);

    conn.on('data', onConnData);
    conn.once('close', onConnClose);
    conn.on('error', onConnError);


    function onConnData(data) {
        document.getElementById('drop1').disabled         = false;
        document.getElementById('reg_button').disabled    = false;

        document.getElementById('mode_btn').disabled      = true;
        document.getElementById('auto_mode_btn').disabled = true;
        document.getElementById('level_input').disabled   = true;
        document.getElementById('drop5').disabled         = true;
        document.getElementById('wm_program').disabled    = true;
        document.getElementById('wm_cent').disabled       = true;
        document.getElementById('temp_in').disabled       = true;
        document.getElementById('umidity_in').disabled    = true;
        document.getElementById('drop2').disabled         = true;
        document.getElementById('drop3').disabled         = true;
        document.getElementById('drop4').disabled         = true;

        //console.log('connection data from %s: %j', remoteAddress, data);
        let json_data = JSON.parse(data);
        //let room = document.getElementById('drop1').innerHTML;
        let ip   = document.getElementById('ip_addr');
        let type = document.getElementById('node_type');

        ip.innerHTML = json_data.ip;

        if(json_data.type == "temperature_humidity sensor"){
            type.innerHTML = "Temp. & Hum. sensor";
        }else{
            type.innerHTML = json_data.type;
        }

    }

    function onConnClose() {
        //console.log('connection from %s closed', remoteAddress);
    }

    function onConnError(err) {
        //console.log('Connection %s error: %s', remoteAddress, err.message);
    }
}



function handle_alarm_system(state){
    if(alarm_act == 1 && state == 1){
        document.getElementById('ring_text').hidden = false;
        document.getElementById('alarm_img').src = '../images/alarm_on.png';
        document.getElementById('alarm_status').innerHTML = "State: ON"
    }else if(state == 0){
        document.getElementById('ring_text').hidden = true;
        document.getElementById('alarm_img').src = '../images/alarm_off.png';
        document.getElementById('alarm_status').innerHTML = "State: OFF"
    }
    else {
        document.getElementById('ring_text').hidden = true;
        document.getElementById('alarm_img').src = '../images/alarm_off.png';
        document.getElementById('alarm_status').innerHTML = "State: ON"
    }
}




function new_node_reg(){
    let room = document.getElementById('drop1').innerHTML;

    if(room != "Select"){
        let back_json = '{ "room" : "' + room + '" , "ip" : "' + document.getElementById('ip_addr').innerHTML + '" , "type" : "' + document.getElementById('node_type').innerHTML + '" }';

        socket.write(back_json);

        document.getElementById('drop1').innerHTML = "Select";
        active_nodes += 1;
        document.getElementById('online_nodes').innerHTML = active_nodes;
        document.getElementById('ip_addr').innerHTML      = "-";
        document.getElementById('node_type').innerHTML    = "-";
        document.getElementById('drop1').disabled         = true;
        document.getElementById('reg_button').disabled    = true;

        document.getElementById('mode_btn').disabled      = false;
        document.getElementById('auto_mode_btn').disabled = false;
        document.getElementById('level_input').disabled   = false;
        document.getElementById('drop5').disabled         = false;
        document.getElementById('wm_program').disabled    = false;
        document.getElementById('wm_cent').disabled       = false;
        document.getElementById('temp_in').disabled       = false;
        document.getElementById('umidity_in').disabled    = false;
        document.getElementById('drop2').disabled         = false;
        document.getElementById('drop3').disabled         = false;
        document.getElementById('drop4').disabled         = false;
    }
}




function change_query_type(caller){
    if(caller == "get"   ){ document.getElementById('drop3').innerHTML  = "get";    }
    if(caller == "post"  ){ document.getElementById('drop3').innerHTML  = "post";   }
    if(caller == "notify"){ document.getElementById('drop3').innerHTML  = "notify"; }
    if(caller == "no_type"){ document.getElementById('drop3').innerHTML = "no type";   }
}


function change_query_resource(caller){
    if(caller == "aa"){ document.getElementById('drop4').innerHTML = "alarm actuator";      }
    if(caller == "as"){ document.getElementById('drop4').innerHTML = "alarm sensor";        }
    if(caller == "lb"){ document.getElementById('drop4').innerHTML = "light bulb";          }
    if(caller == "ls"){ document.getElementById('drop4').innerHTML = "light sensor";        }
    if(caller == "ps"){ document.getElementById('drop4').innerHTML = "presence sensor";     }
    if(caller == "br"){ document.getElementById('drop4').innerHTML = "roller blind";        }
    if(caller == "wm"){ document.getElementById('drop4').innerHTML = "washing machine";     }
    if(caller == "hc"){ document.getElementById('drop4').innerHTML = "hvac";                }
    if(caller == "tu"){ document.getElementById('drop4').innerHTML = "Temp. & Hum. sensor"; }
    if(caller == "nr"){ document.getElementById('drop4').innerHTML = "Resource";            }
}



//Gestisce la logica del query selector
function handle_query_sel(){
    let room         = document.getElementById('drop2').innerHTML;
    let request_type = document.getElementById('drop3').innerHTML;
    let resource     = document.getElementById('drop4').innerHTML;

    let mode_btn     = document.getElementById('mode_btn');
    let auto_mode    = document.getElementById('auto_mode_btn');
    let level        = document.getElementById('level_input').value;
    let color        = document.getElementById('drop5').innerHTML;

    let program      = document.getElementById('wm_program').value;
    let centrif      = document.getElementById('wm_cent').value;

    let temp         = document.getElementById('temp_in').value;
    let humidity     = document.getElementById('umidity_in').value;

    let find_btn     = document.getElementById('query_btn');
    find_btn.disabled = true;

    //console.log(request_type, resource, mode_btn, level, color, program, centrif, temp, humidity);

    if(request_type == "get"   ){ document.getElementById('query_btn').innerHTML = '<i class="material-icons right">search</i>Get data'; }

    //per le risorse washing machine e alarm actuator i tempi di osservabilita' sono diversi e sempre  >> 30 secondi
    if(request_type == "notify" && resource != "alarm actuator" && resource != "washing machine"){ 
        document.getElementById('query_btn').innerHTML = '<i class="material-icons right">synch</i>Retrieve data (30 seconds)';
    }else{
        document.getElementById('query_btn').innerHTML = '<i class="material-icons right">synch</i>Retrieve data';
    }

    if( resource == "alarm sensor" || resource == "light sensor" || resource == "presence sensor" ||
        resource == "Temp. &amp; Hum. sensor"){

            if(request_type != "get" && request_type != "notify"){
                document.getElementById('drop3').innerHTML = "get";
            }

            if( (resource == "alarm sensor" || resource == "presence sensor") && request_type == "notify" ){
                document.getElementById('drop3').innerHTML = "get";   
            }

            document.getElementById('mode_btn').disabled      = true;
            document.getElementById('auto_mode_btn').disabled = true;
            document.getElementById('level_input').disabled   = true;
            document.getElementById('drop5').disabled         = true;
            document.getElementById('wm_program').disabled    = true;
            document.getElementById('wm_cent').disabled       = true;
            document.getElementById('temp_in').disabled       = true;
            document.getElementById('umidity_in').disabled    = true;

    }else{
        document.getElementById('mode_btn').disabled      = false;
        document.getElementById('auto_mode_btn').disabled = false;
        document.getElementById('level_input').disabled   = false;
        document.getElementById('drop5').disabled         = false;
        document.getElementById('wm_program').disabled    = false;
        document.getElementById('wm_cent').disabled       = false;
        document.getElementById('temp_in').disabled       = false;
        document.getElementById('umidity_in').disabled    = false;
    }

    if(request_type == "post"){
        document.getElementById('query_btn').innerHTML   = '<i class="material-icons right">send</i>Send data';

      if(resource == "washing machine"){
        document.getElementById('level_input').disabled   = true;
        document.getElementById('drop5').disabled         = true;
        document.getElementById('temp_in').disabled       = true;
        document.getElementById('umidity_in').disabled    = true;
        document.getElementById('auto_mode_btn').disabled = true;
      }

      if(resource == "light bulb"){
        document.getElementById('wm_program').disabled  = true;
        document.getElementById('wm_cent').disabled     = true;
        document.getElementById('temp_in').disabled     = true;
        document.getElementById('umidity_in').disabled  = true;

        if(document.getElementById('auto_mode_btn').checked){             //se la mode == auto allora disabilito la scelta del colore e forzo il giallo
            document.getElementById('drop5').disabled         = true;
            document.getElementById('level_input').disabled   = true;
            document.getElementById('drop5').innerHTML        = "yellow";
        }
      }

      if(resource == "alarm actuator"){
        document.getElementById('level_input').disabled   = true;
        document.getElementById('drop5').disabled         = true;
        document.getElementById('wm_program').disabled    = true;
        document.getElementById('wm_cent').disabled       = true;
        document.getElementById('temp_in').disabled       = true;
        document.getElementById('umidity_in').disabled    = true;
        document.getElementById('auto_mode_btn').disabled = true;
      }

      if(resource == "roller blind"){
        document.getElementById('drop5').disabled         = true;
        document.getElementById('wm_program').disabled    = true;
        document.getElementById('wm_cent').disabled       = true;
        document.getElementById('temp_in').disabled       = true;
        document.getElementById('umidity_in').disabled    = true;
        document.getElementById('auto_mode_btn').disabled = true;
      }

      if(resource == "hvac"){
        document.getElementById('level_input').disabled   = true;
        document.getElementById('drop5').disabled         = true;
        document.getElementById('wm_program').disabled    = true;
        document.getElementById('wm_cent').disabled       = true;
        document.getElementById('auto_mode_btn').disabled = true;
      }
    }

    request_type = document.getElementById('drop3').innerHTML; //devo riprendere il valore perche' puo' essere stato cambiato alla riga 160

    if(request_type != "Type" && room != "Select"  && resource != "Resource"){
        find_btn.disabled = false;

        let client = new net.Socket();

        client.connect(10001, '127.0.0.1', function() {
            //vale per tutti i tipi di richiesta
            let json_data = '{ "room" : "' + room + '" , "resource" : "' + resource + '" }';

            client.write(json_data);
        });


        client.on('data', function(data) {
            let tcp_response = JSON.parse(data);                        //questi sono gli ip dei nodi che combaciano con i paramentri della query

            if(tcp_response.hasOwnProperty('sens_nr')){
                let sens_nr = tcp_response['sens_nr'];                  //lo lascio cosi' (stringa) perche' e' conveniente per settarlo dopo come proprieta'

                if(parseInt(sens_nr) == 0){
                    document.getElementById('sens_id').disabled = true; //se c'e' solo un sensore non e' possibile selezionarne altri... il campo e' disabilitato
                }else{
                    document.getElementById('sens_id').max = sens_nr;   //qui e' piu' efficiente perche' la proprieta' e' espressa come stringa
                }
            }

            client.destroy();                                           //chiude il client dopo che riceve la risposta

        })
    }else{
        document.getElementById('mode_btn').disabled    = false;
        document.getElementById('level_input').disabled = false;
        document.getElementById('drop5').disabled       = false;
        document.getElementById('wm_program').disabled  = false;
        document.getElementById('wm_cent').disabled     = false;
        document.getElementById('temp_in').disabled     = false;
        document.getElementById('umidity_in').disabled  = false;
    }

}




function populate_query_result(json_result, uri, req_type, room){
    //console.log("Qui dentro -->  ", json_result);
    json_result = JSON.parse(json_result);

    let ul           = document.getElementById('query_res_list');
    let li           = document.createElement("li");

    //solo per le get?????? perchè per le post i json di ritorno sono tutti diversi
    //gli if non si possono fare così, in json_result non c'è l'uri. và modificato il pacchetto in cooja
    if(uri == "alarm_s"){
        let state = "Detected no presence";

        if(json_result['alarm'] == "1")
            state = "Detected presence";


        let info = state;
        let t    = "Alarm sensor state:"
        //andrebbero aggiunte altre informazioni come l'id, la stanza
        li.innerHTML =  '<div style="float: left; width: 400px; height: 50px;">' +
                            '<p style="float: left; margin-left: 10%; margin-top: 20%;font-size: 20px;">'  + t + '</p> ' +
                            '<p style="float: left; margin-left: 10%; margin-top: 0%;font-size: 20px;">'  + info + '</p> ' +
                        '</div> ';

        ul.appendChild(li);
    }

    if(uri == "washing_m"){
        let mode = document.getElementById('wm_state');
        let program = document.getElementById('wm_prog');
        let centrifuge =  document.getElementById('wm_centr');
        let time =  document.getElementById('wm_time');

        //////////////// per le GET /////////////////////////
        if (json_result.hasOwnProperty('status') && json_result.hasOwnProperty('mode')) {

            if(json_result['mode'] == 'start')
                mode.innerHTML = 'State: ON';

            if(json_result['mode'] == 'pause')
                mode.innerHTML = 'State: PAUSE';

            if(json_result['mode'] == 'pause')
                mode.innerHTML = 'State: OFF';

            program.innerHTML = 'Program: ' + json_result['program'];
            centrifuge.innerHTML = 'Centrifuge: ' + json_result['centrifuge'];
            time.innerHTML = 'Time: ' + json_result['r_time'] + ' s';
        }

        if (json_result.hasOwnProperty('status') && !json_result.hasOwnProperty('mode')) {

            mode.innerHTML = 'State: OFF';
            program.innerHTML = 'Program: -' ;
            centrifuge.innerHTML = 'Centrifuge: -' ;
            time.innerHTML = 'Time: -' + '-';
        }

        //////////////////////////Per le post//////////////////////////////////
        if (!json_result.hasOwnProperty('status')) {
            let m = document.getElementById('mode_btn').checked;
            let p = document.getElementById('wm_program').value;
            let c =  document.getElementById('wm_cent').value;

            if(m){m = 'ON';}
            else {m = 'OFF';}

            let response = json_result['response_code'];
            let info;

            if(response == '0'){
                info = "Response: Bad Post";
                li.innerHTML =  '<div style="float: left; width: 290px; height: 30px;">' +
                                    '<p style="float: left; margin-left: 10%; margin-top: 20%;font-size: 20px;">'  + info + '</p> ' +
                                '</div> ';

                ul.appendChild(li);
            }

            else{
                mode.innerHTML = 'State: ' + m;
                program.innerHTML = 'Program: '+ p;
                centrifuge.innerHTML = 'Centrifuge: ' + c ;
                time.innerHTML = 'Time: -' + ' s';
            }
        }
    }

    if(uri == "light_bulb"){
        let title_h = document.getElementById('light_bulb_title');
        title_h.innerHTML = room + ' light bulb';

        let mode_h = document.getElementById('light_bulb_state');
        let bright_h = document.getElementById('light_bulb_bright');
        let color_h =  document.getElementById('bulb_renderer');
        ////// response per la get//////

        if (json_result.hasOwnProperty('mode')) {
            let mode = json_result['mode'];
            let brightness = json_result['brightness'];
            let color = json_result['color'];

            mode_h.innerHTML = "State: " + mode;
            bright_h.innerHTML = "Brightness: " + brightness;

            if(brightness < 10){ brightness = 10; }               //senno' scompare l'immagine della lampadina
            color_h.style.opacity = parseInt(brightness)/100;

            if(mode == 'on'){
                if(color == 'y'){color_h.style.color = 'yellow';}
                if(color == 'g'){color_h.style.color = 'green';}
                if(color == 'r'){color_h.style.color = 'red';}
            }

            if(mode == 'off'){
                color_h.style.color = 'black';
                color_h.style.opacity = 1;
            }

            if(mode == 'auto'){
                color_h.style.color = 'yellow';
            }
        }

        ////////////////////POST////////////////////
        if (!json_result.hasOwnProperty('mode')) {
            let m = document.getElementById('mode_btn').checked;
            let a = document.getElementById('auto_mode_btn').checked;
            let l = document.getElementById('level_input').value;
            let c =  document.getElementById('drop5').innerHTML;

            if(m){m = 'ON';}
            else {m = 'OFF';}

            if(a){ m = 'AUTO'; }

            let response = json_result['response_code'];
            let info;
            if(response == '0'){
                info = "Response: Bad Post";
                li.innerHTML =  '<div style="float: left; width: 290px; height: 30px;">' +
                                    '<p style="float: left; margin-left: 10%; margin-top: 20%;font-size: 20px;">'  + info + '</p> ' +
                                '</div> ';

                ul.appendChild(li);
            }
            else{
                title_h.innerHTML = room + ' light bulb';
                mode_h.innerHTML = 'State: ' + m;
                bright_h.innerHTML = 'Brightness: '+ l;

                if(m == "OFF" ){ color_h.style.color = "black";  color_h.style.opacity = 1;   }
                if(m == "ON"  ){ color_h.style.color = c      ;  color_h.style.opacity = l;   }
                if(m == "AUTO"){ color_h.style.color = "yellow"; color_h.style.opacity = 0.5; }
            }
        }

    }

    if(uri == "light_s"){
        if(json_result.hasOwnProperty('req_type')){
            ylight.push(parseInt(json_result['light']));
            xtime.push(parseFloat(json_result['elaps']));
            //console.log(ylight, xtime);
            graph_rendering_light(room + " brightness", xtime, ylight);
        }
        else{
            let info = "Percentage of light: " + json_result['light'];
            //andrebbero aggiunte altre informazioni come l'id, la stanza
            li.innerHTML =  '<div style="float: left; width: 400px; height: 50px;">' +
                                '<p style="float: left; margin-left: 10%; margin-top: 20%;font-size: 20px;">' + info + '</p> ' +
                            '</div> ';

            ul.appendChild(li);
        }

    }

    if(uri == "presence_s"){

        let state = "Detected no presence";

        if(json_result['alarm'] == "1"){
            state = "Detected presence";
        }

        let t    = "Presence sensor state: ";
        let info =  state;

        //andrebbero aggiunte altre informazioni come l'id, la stanza
        li.innerHTML =  '<div style="float: left; width: 400px; height: 50px;">' +
                            '<p style="float: left; margin-left: 10%; margin-top: 20%;font-size: 20px;">'  + t + '</p> ' +
                            '<p style="float: left; margin-left: 10%; margin-top: 0%;font-size: 20px;">'  + info + '</p> ' +
                        '</div> ';

        ul.appendChild(li);

    }

    if(uri == "alarm_act"){
        //////////////// per le GET /////////////////////////
        if (json_result.hasOwnProperty('status') && json_result.hasOwnProperty('mode')) {

            if(json_result['mode'] == 'on' && json_result['status'] == 'sound'){
                alarm_act = 1;
                handle_alarm_system(1);
            }
            else if(json_result['mode'] == 'on' && json_result['status'] == 'ok'){
                alarm_act = 0;
                handle_alarm_system(1);
            }

            else if(json_result['mode'] == 'off'){
                alarm_act = 0;
                handle_alarm_system(0);
            }
        }

        ///////////////////////////////////////////////////////////////////////
        //////////////////////////Per le post//////////////////////////////////
        if (!json_result.hasOwnProperty('mode')) {
            let m = document.getElementById('mode_btn').checked;

            if(m){m = 'State: ON';}
            else {m = 'State: OFF';}

            let response = json_result['response_code']
            let info;

            if(response == '0'){
                info = "Response: Bad Post";
                li.innerHTML =  '<div style="float: left; width: 290px; height: 30px;">' +
                                    '<p style="float: left; margin-left: 10%; margin-top: 20%;font-size: 20px;">'  + info + '</p> ' +
                                '</div> ';

                ul.appendChild(li);
            }
            else{
                document.getElementById('alarm_status').innerHTML = m;
            }
        }
    }

    if(uri == "roller_blind"){
        let title_h = document.getElementById('presence_title');
        title_h.innerHTML = room + ' Roller blind';

        let state_h = document.getElementById('roller_state');
        let alevel_h =  document.getElementById('roller_alevel');
        let dlevel_h =  document.getElementById('roller_dlevel');

        //////////////// per le GET /////////////////////////
        if (json_result.hasOwnProperty('desired_level') && json_result.hasOwnProperty('mode')) {

            let mode = json_result['mode'];
            let level = json_result['actual_level'];
            let d_level = json_result['desired_level'];

            state_h.innerHTML = "State: " + mode;
            alevel_h.innerHTML = "Level: " + level;
            dlevel_h.innerHTML = "Desired level: " + d_level;
        }

        if (!json_result.hasOwnProperty('desired_level') && json_result.hasOwnProperty('mode')) {

            let mode = json_result['mode'];
            let level = json_result['actual_level'];

            state_h.innerHTML = "State: " + mode;
            alevel_h.innerHTML = "Level: " + level;
            dlevel_h.innerHTML = "Desired level: -";
        }

        ///////////////////////////////////////////////////////////////////////
        //////////////////////////Per le post//////////////////////////////////
        if (!json_result.hasOwnProperty('mode')) {
            let m = document.getElementById('mode_btn').checked;
            let l = document.getElementById('level_input').value;

            if(m){m = 'State: ON';}
            else {m = 'State: OFF';}

            let response = json_result['response_code'];
            let info;

            if(response == '0'){
                info = "Response: Bad Post";
                li.innerHTML =  '<div style="float: left; width: 290px; height: 30px;">' +
                                '<p style="float: left; margin-left: 10%; margin-top: 20%;font-size: 20px;">'  + info + '</p> ' +
                                '</div> ';

                ul.appendChild(li);
            }
            else{
                state_h.innerHTML = "State: " + m;
                alevel_h.innerHTML = "Level: -";
                dlevel_h.innerHTML = "Desired level: " + l;
            }
        }

    }
    if(uri == "hvac"){
        let title_h = document.getElementById('hvac_title');
        title_h.innerHTML = room + ' climate system';

        let state_h = document.getElementById('hvac_state');
        let d_temp_h =  document.getElementById('hvac_dtemp');
        let d_hum_h =  document.getElementById('hvac_dhum');
        let prog_h = document.getElementById('hvac_prog');

        //////////////// per le GET /////////////////////////
        if (json_result.hasOwnProperty('des_temp') && json_result.hasOwnProperty('mode')) {

            let mode = json_result['mode'];
            let des_temp = json_result['des_temp'];
            let prog_temp = json_result['prog_temp'];

            state_h.innerHTML = "State: " + mode;
            d_temp_h.innerHTML = "Temperature: " + des_temp + "&deg;";
            prog_h.innerHTML = "Program: " + prog_temp;
        }

        if (json_result.hasOwnProperty('des_hum') && json_result.hasOwnProperty('mode')) {

            let mode = json_result['mode'];
            let des_hum = json_result['des_hum'];
            let prog_hum = json_result['prog_hum'];

            state_h.innerHTML = "State: " + mode;
            d_hum_h.innerHTML = "Humidity: " + des_hum + "%";
            prog_h.innerHTML += " " + prog_hum;
        }


        ///////////////////////////////////////////////////////////////////////
        //////////////////////////Per le post//////////////////////////////////
        if (!json_result.hasOwnProperty('mode')) {
            let m = document.getElementById('mode_btn').checked;
            let t = document.getElementById('temp_in').value;
            let h = document.getElementById('umidity_in').value;

            if(m){m = 'State: ON';}
            else {m = 'State: OFF';}


            let response = json_result['response_code'];
            let info;
            if(response == '0'){
                info = "Response: Bad Post";
                li.innerHTML =  '<div style="float: left; width: 290px; height: 30px;">' +
                                    '<p style="float: left; margin-left: 10%; margin-top: 20%;font-size: 20px;">'  + info + '</p> ' +
                                '</div> ';

                ul.appendChild(li);
            }
            else{
                title_h.innerHTML = room + ' climate system';
                state_h.innerHTML = m;
                d_hum_h.innerHTML = "Humidity: " + h + "%";
                d_temp_h.innerHTML = "Temperature: " + t + "&deg;";
                prog_h.innerHTML = "Program: -";
            }
        }

    }


    if(uri == "temp_hum"){

        if(json_result.hasOwnProperty('req_type')){
            ytemp.push(parseInt(json_result['temp']));
            yhum.push(parseInt(json_result['hum']));
            xtime.push(parseFloat(json_result['elaps']));

            graph_rendering_temp_hum(room + " Temperature & Humidity", xtime, ytemp, yhum);
        }
        else{
            let temp = json_result['temp'];
            let hum  = json_result['hum'];


            let info1 = "Temperature: " + temp + " &deg;"
            let info2 = "Humidity: " + hum + " %";
            //andrebbero aggiunte altre informazioni come l'id, la stanza
            li.innerHTML =  '<div style="float: left; width: 290px; height: 30px;">' +
                                '<p style="float: left; margin-left: 10%; margin-top: 20%;font-size: 20px;">' + info1 + '</p> ' +
                                '<p style="float: left; margin-left: 10%; margin-top: 0%;font-size: 20px;">'   + info2 + '</p> ' +
                            '</div> ';

            ul.appendChild(li);
        }
    }

}







function execute_query_backend(){
    let ul        = document.getElementById('query_res_list');
    ul.innerHTML  = '';

    let room      = document.getElementById('drop2').innerHTML;
    let req_type  = document.getElementById('drop3').innerHTML;
    let resource  = document.getElementById('drop4').innerHTML;

    let mode_btn  = document.getElementById('mode_btn').checked;
    let auto_mode = document.getElementById('auto_mode_btn').checked;

    if(resource == "washing machine" && mode_btn){   mode_btn = "start"; }
    if(resource == "washing machine" && !mode_btn){  mode_btn = "pause"; }

    if((resource == "roller blind" || resource == "hvac" || resource == "alarm actuator" || resource == "light bulb")  &&  mode_btn){  mode_btn = "on";  }
    if((resource == "roller blind" || resource == "hvac" || resource == "alarm actuator" || resource == "light bulb")  && !mode_btn){  mode_btn = "off"; }

    if(resource == "light bulb" && auto_mode){ mode_btn = "auto"; } //solo se viene attivato lo switch della modalita' automatica

    let level = document.getElementById('level_input').value;
    let prog  = document.getElementById('wm_program').value;
    let centr = document.getElementById('wm_cent').value;
    let color = document.getElementById('drop5').innerHTML;
    let temp  = document.getElementById('temp_in').value;
    let hum   = document.getElementById('umidity_in').value;

    if(color == "yellow" ){ color = "y"; }
    if(color == "green"  ){ color = "g"; }
    if(color == "red"    ){ color = "r"; }
    if(mode_btn == "auto"){ color = "y"; }

    document.getElementById('mode_btn').disabled    = false;
    document.getElementById('level_input').disabled = false;
    document.getElementById('drop5').disabled       = false;
    document.getElementById('wm_program').disabled  = false;
    document.getElementById('wm_cent').disabled     = false;
    document.getElementById('temp_in').disabled     = false;
    document.getElementById('umidity_in').disabled  = false;
    document.getElementById('auto_mode_btn').disabled = false;

    //client TCP
    let client = new net.Socket();
    let uri = "";
    let json_data = "";

    /////////////////////////////////////////////////////CREAZIONE PAYLOAD PER LA POST DI SECONDO LIVELLO//////////////////////////////////////////////////
    let json_payload = "";

    if(resource == "washing machine"){ json_payload = '{ "mode" : "' + mode_btn + '" , "program" : "' + prog + '" , "centrifuge" : " ' + centr + '" }'; }
    if(resource == "hvac"           ){ json_payload = '{ "mode" : "' + mode_btn + '" , "temp" : "' + temp + '" , "hum" : " ' + hum + '" }'; }
    if(resource == "alarm actuator" ){ json_payload = '{ "mode" : "' + mode_btn + '" }'; }
    if(resource == "light bulb"     ){ json_payload = '{ "mode" : "' + mode_btn + '" , "brightness" : "' + level + '" , "color" : " ' + color + '" }'; }
    if(resource == "roller blind"   ){ json_payload = '{ "mode" : "' + mode_btn + '" , "level" :"' + level + '"}'; }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    client.connect(10001, '127.0.0.1', function() {
        if(resource == "washing machine"     ){ uri = "washing_m";    } //lo "/" iniziale sta gia' in client.py
        if(resource == "light bulb"          ){ uri = "light_bulb";   }
        if(resource == "light sensor"        ){ uri = "light_s";      }
        if(resource == "presence sensor"     ){ uri = "presence_s";   }
        if(resource == "alarm actuator"      ){ uri = "alarm_act";    }
        if(resource == "alarm sensor"        ){ uri = "alarm_s";      }
        if(resource == "roller blind"        ){ uri = "roller_blind"; }
        if(resource == "hvac"                ){ uri = "hvac";         }
        if(resource == "Temp. &amp; Hum. sensor" ){ uri = "temp_hum"; resource = "temperature_humidity sensor"; }

       

        //vale per tutti i tipi di richiesta
        json_data = '{ "room" : "' + room + '" , "resource" : "' + resource + '" }';
        client.write(json_data);
    });


    client.on('data', function(data) {
        let tcp_response = JSON.parse(data);                        //questi sono gli ip dei nodi che combaciano con i paramentri della query
        let ret_values;                                            //vettore al caso peggiore valgono tutti i nodi attivi nel sistema

        let selected_sens = document.getElementById('sens_id').value;
        let node_number = parseInt(tcp_response['sens_nr']);

        if(node_number == 0){
            let li           = document.createElement("li");

            let info1 = "No node " + resource;
            let info2 = "find in " + room;

            li.innerHTML =  '<div style="float: left; width: 290px; height: 30px;">' +
                                '<p style="float: left; margin-left: 10%; margin-top: 20%;font-size: 20px;">' + info1 + '</p> ' +
                                '<p style="float: left; margin-left: 10%; margin-top: 0%;font-size: 20px;">' + info2 + '</p> ' +
                            '</div> ';

            ul.appendChild(li);
        }

        // '-u' per non bufferizzare le print lato python... molto bene
        if((req_type == 'NOTIFY' || req_type == 'notify') && (uri == 'temp_hum' || uri == 'light_s') && counter_notify > 60){
            counter_notify = 0;
            ytemp        = [];
            yhum         = [];
            ylight       = [];
            xtime        = [];
        }


        if((req_type == 'notify') && (counter_notify == 0)){
            if((uri == 'temp_hum' || uri == 'light_s')){
                setInterval(incrementSeconds, 1000);
            }

            ret_values = require('child_process').spawn('python3', [ '-u', 'python_backend/client.py', tcp_response['ip_'+selected_sens], uri, req_type, json_payload]);

            ret_values.stdout.on('data',function(data){
                data = data.toString('utf8');
                populate_query_result(data, uri, req_type, room);
            });

            client.destroy(); // kill client after server's response
        }

        if((req_type == 'notify') && !(uri == 'temp_hum' || uri == 'light_s')){
            ret_values = require('child_process').spawn('python3', [ '-u', 'python_backend/client.py', tcp_response['ip_'+selected_sens], uri, req_type, json_payload]);

            ret_values.stdout.on('data',function(data){
                data = data.toString('utf8');
                populate_query_result(data, uri, req_type, room);
            });

            client.destroy(); // kill client after server's response
        }

        else if (req_type != 'notify'){
            ret_values = require('child_process').spawn('python3', [ '-u', 'python_backend/client.py', tcp_response['ip_'+selected_sens], uri, req_type, json_payload]);

            ret_values.stdout.on('data',function(data){
                data = data.toString('utf8');
                populate_query_result(data, uri, req_type, room);
            });

            client.destroy(); // kill client after server's response
        }


    });


    client.on('close', function() {});

}


function graph_rendering_temp_hum(tit, data_x, data1_y, data2_y){

    let trace1 = {
        name: "Temperature",
        yaxis: "y1",
        x: data_x,
        y: data1_y,
        mode: 'lines+markers',
        type: 'scatter',
        marker: {
          color: 'rgb(85,90,165)',
        }
      };

    let trace2 = {
        name: "Humidity",
        yaxis: "y2",
        x: data_x,
        y: data2_y,
        mode: 'lines+markers',
        type: 'scatter',
        marker: {
          color: 'rgb(158,202,225)',
        }
      };


      let layout = {
        title: tit,
        width: 850,
        height: 300,
        margin: {
            l: 35,
            r: 10,
            b: 50,
            t: 80,
            pad: 4
          },
        xaxis: {
            range: [ 0, 30 ],
            dtick: 1
          },
          yaxis: {
            range: [-10, 40],
            title: 'Degrees',
            overlaying: 'y2',
            titlefont: {color: 'rgb(85,90,165)'},
            tickfont: {color: 'rgb(85,90,165)'}
          },
          yaxis2: {
            range: [0, 100],
            title: 'Percentage',
            side: "right",
            titlefont: {color: 'rgb(158,202,225)'},
            tickfont: {color: 'rgb(158,202,225)'}
          },

          showlegend: true,
          legend: {
              x: 1.25,
              xanchor: 'right',
              y: 0.8
          }
      };

      Plotly.newPlot('graph', [trace1, trace2], layout);
}


function graph_rendering_light(tit, data_x, data_y){

    let trace1 = {
        name: "Light",
        yaxis: "y1",
        x: data_x,
        y: data_y,
        mode: 'lines+markers',
        type: 'scatter',
        marker: {
          color: 'rgb(250,165,25)',
        }
      };

      let layout = {
        title: tit,
        width: 850,
        height: 300,
        margin: {
            l: 35,
            r: 10,
            b: 50,
            t: 80,
            pad: 4
          },
        xaxis: {
            range: [ 0, 30 ],
            dtick: 1
          },
          yaxis: {
            range: [0, 100],
            title: 'Percentage',
            titlefont: {color: 'rgb(250,165,25)'},
            tickfont: {color: 'rgb(250,165,25)'}
          },

          showlegend: true,
          legend: {
              x: 1.25,
              xanchor: 'right',
              y: 0.8
          }

      };

      Plotly.newPlot('graph', [trace1], layout);
}
