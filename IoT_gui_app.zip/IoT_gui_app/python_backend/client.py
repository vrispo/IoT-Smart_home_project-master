import asyncio, aiocoap
from aiocoap import *
import sys
from threading import Thread
import time

#########################################
IP       = 1    #parametro 1
RESOURCE = 2    #parametro 2
REQ_TYPE = 3    #parametro 3
PAYLOAD  = 4    #parametro 4
#########################################

OBSERVATION_TIME = 30

if(sys.argv[RESOURCE] == 'washing_m'):
    OBSERVATION_TIME = 150

if(sys.argv[RESOURCE] == 'alarm_act'):
    OBSERVATION_TIME = -1



time_ref         = time.time()
elapsed_time     = 0






def obs_call(response):

    data = response.payload.decode('ascii').replace('}', ',"elaps":') + '"' +str(elapsed_time)[:5] + '" , "req_type": "NOTIFY"' + '}'
    print(data)

async def coap_get_with_observer():
    protocol = await Context.create_client_context()
    full_uri = 'coap://[' + sys.argv[IP] + ']/' + sys.argv[RESOURCE]
    request = Message(code= GET, uri= full_uri, observe=0)     #coap://localhost...

    pr = protocol.request(request)

    r = await pr.response
    data = r.payload.decode('ascii').replace('}', ',"elaps":') + '"' +str(0) + '" , "req_type": "NOTIFY"' + '}'
    print(data)

    pr.observation.register_callback(obs_call)



async def coap_post_from_gui():
    context = await Context.create_client_context()

    full_uri = 'coap://[' + sys.argv[IP] + ']/' + sys.argv[RESOURCE]
    payload = str(sys.argv[PAYLOAD]).encode('ascii')
    request = Message(code= POST, payload= payload, uri=full_uri)

    response = await context.request(request).response

    print(response.payload.decode('ascii'))




async def coap_get_from_gui():
    protocol = await Context.create_client_context()

    full_uri = 'coap://[' + sys.argv[IP] + ']/' + sys.argv[RESOURCE]
    payload_data = ""
    requested_res = Message(code= GET, payload=payload_data.encode('ascii'), uri= full_uri)     #coap://localhost...

    try:
        response = await protocol.request(requested_res).response   #aspetto la risposta
    except Exception as e:
        print(response.payload.decode('ascii'))                                                          #non stampo piu' nulla senno' andrei allo std output
    else:
        if(str(response.code).split(" ")[0] == "2.05"):     #il codice 2.05 è definito dallo std CoAP ed è equivalente al codice 200 in HTTP
            print(response.payload.decode('ascii'))                 #l'encode deve essere esplicitato in 'ascii' perchè di base è utf-8





def thread_body(loop):
    global time_ref
    global elapsed_time

    while( elapsed_time < OBSERVATION_TIME ):
        elapsed_time += time.time() - time_ref
        time_ref = time.time()


    loop.stop()




if __name__ == "__main__" :
    if(sys.argv[REQ_TYPE] == "GET" or sys.argv[REQ_TYPE] == "get"):
        asyncio.get_event_loop().run_until_complete(coap_get_from_gui())

    if(sys.argv[REQ_TYPE] == "POST" or sys.argv[REQ_TYPE] == "post"):
        asyncio.get_event_loop().run_until_complete(coap_post_from_gui())

    if(sys.argv[REQ_TYPE] == "NOTIFY" or sys.argv[REQ_TYPE] == "notify"):
        try:
            event_loop = asyncio.new_event_loop()
            asyncio.set_event_loop(event_loop)
            event_loop.create_task(coap_get_with_observer())

            if(OBSERVATION_TIME != -1):
                counter_thread = Thread(target= thread_body, args=(event_loop,))
                counter_thread.start()

            asyncio.get_event_loop().run_forever()


        except:
            print("{}")
